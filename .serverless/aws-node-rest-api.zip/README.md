# first-aws-lambda-api

- make sure you install the serverless framework, have node, typescript installed and configured...all that good stuff.

```
npm i -g serverless
npm i typescript

```
